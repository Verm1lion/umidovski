# data_bundle — sızıntısız CV ↔ İlan veri paketi

Bu klasör `scripts/05_build_dataset.py` tarafından üretilir ve Colab notebook'una
(`CV_Ilan_SOTA_Egitim_ve_Test_A100.ipynb`) tek dosya (`data_bundle.zip`) olarak yüklenir.

| Dosya | İçerik |
|---|---|
| clean_cvs.parquet | Tüm CV'ler (gerçek + yalnızca train'de sentetik). `cv_struct` = standart semantik şablon. `split` ∈ {train,val,test}. `gold_*` sütunları YALNIZCA değerlendirme içindir. |
| clean_jobs.parquet | 3.000 ilan. `job_struct`, `job_pool` ∈ {warm,cold}. `gold_*` sütunları YALNIZCA değerlendirme içindir. |
| train_triplets.parquet | anchor CV + pozitif ilan + 3 tür zor negatif (lexical / seniority-collar / BM25). |
| val_triplets.parquet | Doğrulama kaybı için aynı biçim (val CV'leri). |
| {train,val,test}_queries.parquet | Sorgu kimlikleri ve sorgu metni (gold yok). |
| qrels_ground_truth.parquet | (cv_id, job_key, grade∈{1,2,3}); listede olmayan çiftler grade 0. |
| legacy_train_pairs.parquet | Eski `train.csv`'nin yalnızca yeni train bölümündeki CV'lere ait satırları (Baseline-3). |
| metadata.json | Kurallar, istatistikler, sızıntı kontrolleri, SHA-256 özetleri. |
| match_candidate_sota.py | Eğitim ve çıkarımın ortak çekirdeği (özellikler, BM25, metrikler, çıkarım sınıfı). |

`legacy_*` sütunları eski sistemin alanlarıdır; CV tarafında `legacy_collar`/`legacy_city` altın etikete denktir —
YALNIZCA Baseline-3 sızıntı gösterimi içindir, özellik olarak kullanılamaz (`assert_no_gold_columns` bunları da reddeder).

Alaka dereceleri:
* 3 — aynı uzmanlık + yaka uyumu + |kıdem farkı| ≤ 1 + lokasyon uyumu (aynı şehir / Remote)
* 2 — aynı ISCO-08 birim grubu + yaka uyumu + |kıdem farkı| ≤ 2
* 1 — yaka uyumu + (aynı ana sektör veya aynı ISCO grubu ama kıdem farkı ≥ 3)
* 0 — diğer
